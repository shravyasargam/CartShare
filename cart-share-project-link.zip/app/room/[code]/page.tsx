import type { Metadata } from 'next'
import { RoomApp } from '@/components/room/room-app'

export async function generateMetadata({ params }: PageProps<'/room/[code]'>): Promise<Metadata> {
  const { code } = await params
  return { title: `Room ${code.toUpperCase()}`, robots: { index: false } }
}

export default async function RoomPage({ params }: PageProps<'/room/[code]'>) {
  const { code } = await params
  return <RoomApp code={code.toUpperCase()} />
}
