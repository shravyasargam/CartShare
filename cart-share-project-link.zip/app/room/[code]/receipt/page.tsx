import type { Metadata } from 'next'
import { ReceiptView } from '@/components/receipt/receipt-view'

export async function generateMetadata({ params }: PageProps<'/room/[code]/receipt'>): Promise<Metadata> {
  const { code } = await params
  return { title: `Receipt · ${code.toUpperCase()}`, robots: { index: false } }
}

export default async function ReceiptPage({ params }: PageProps<'/room/[code]/receipt'>) {
  const { code } = await params
  return <ReceiptView code={code.toUpperCase()} />
}
