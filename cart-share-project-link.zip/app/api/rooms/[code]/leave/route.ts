import { handle, parseCode } from '@/lib/server/http'
import { readSessionToken } from '@/lib/server/session'
import { leaveRoom } from '@/lib/server/store'

export async function POST(_request: Request, ctx: RouteContext<'/api/rooms/[code]/leave'>) {
  return handle(async () => {
    const { code } = await ctx.params
    return leaveRoom(parseCode(code), await readSessionToken())
  })
}
