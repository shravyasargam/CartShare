import { handle, parseCode, readJson } from '@/lib/server/http'
import { readSessionToken } from '@/lib/server/session'
import { addItem } from '@/lib/server/store'
import { itemInputSchema } from '@/lib/validation'

export async function POST(request: Request, ctx: RouteContext<'/api/rooms/[code]/items'>) {
  return handle(async () => {
    const { code } = await ctx.params
    const input = itemInputSchema.parse(await readJson(request))
    return addItem(parseCode(code), await readSessionToken(), input)
  })
}
