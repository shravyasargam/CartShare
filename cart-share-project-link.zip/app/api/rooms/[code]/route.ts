import { handle, parseCode } from '@/lib/server/http'
import { readSessionToken } from '@/lib/server/session'
import { getRoomState } from '@/lib/server/store'

export async function GET(_request: Request, ctx: RouteContext<'/api/rooms/[code]'>) {
  return handle(async () => {
    const { code } = await ctx.params
    return getRoomState(parseCode(code), await readSessionToken())
  })
}
