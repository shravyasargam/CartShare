import { handle, readJson } from '@/lib/server/http'
import { getOrCreateSessionToken } from '@/lib/server/session'
import { createRoom } from '@/lib/server/store'
import { createRoomSchema } from '@/lib/validation'

export async function POST(request: Request) {
  return handle(async () => {
    const input = createRoomSchema.parse(await readJson(request))
    const token = await getOrCreateSessionToken()
    return createRoom(input, token)
  })
}
