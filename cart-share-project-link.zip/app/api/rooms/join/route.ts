import { handle, readJson } from '@/lib/server/http'
import { getOrCreateSessionToken } from '@/lib/server/session'
import { joinRoom } from '@/lib/server/store'
import { joinRoomSchema } from '@/lib/validation'

export async function POST(request: Request) {
  return handle(async () => {
    const input = joinRoomSchema.parse(await readJson(request))
    const token = await getOrCreateSessionToken()
    return joinRoom(input, token)
  })
}
