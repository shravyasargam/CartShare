import Link from 'next/link'
import { CheckCircle2 } from 'lucide-react'
import { BrandLogo } from '@/components/brand'
import { DemoBanner } from '@/components/demo-banner'
import { EntryCard } from '@/components/welcome/entry-card'
import { HowItWorks } from '@/components/welcome/how-it-works'
import { APP_CONFIG } from '@/lib/config'
import { roomCodeSchema } from '@/lib/validation'

const HIGHLIGHTS = ['Live shared cart', 'Contribution tracking', 'Printable group receipt']

export default async function HomePage({ searchParams }: PageProps<'/'>) {
  const { code } = await searchParams
  const parsed = roomCodeSchema.safeParse(typeof code === 'string' ? code : '')
  const initialCode = parsed.success ? parsed.data : ''

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b bg-card/80 backdrop-blur">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
          <BrandLogo />
          <nav aria-label="Main">
            <Link
              href="/about"
              className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              About the project
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="relative overflow-hidden border-b bg-gradient-to-b from-secondary/60 to-background">
          <div className="mx-auto grid w-full max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:py-20">
            <div>
              <p className="inline-flex items-center rounded-full border bg-card px-3 py-1 text-xs font-medium text-secondary-foreground">
                {APP_CONFIG.tagline}
              </p>
              <h1 className="mt-5 text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
                Your group&apos;s shopping, all in one place.
              </h1>
              <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty">
                CartShare gives roommates, students, office teams, and travel groups one shared cart. Add products,
                see who added what, watch the total grow in real time, and split the bill without the chaos.
              </p>
              <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
                {HIGHLIGHTS.map((h) => (
                  <li key={h} className="flex items-center gap-2 text-sm font-medium">
                    <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />
                    {h}
                  </li>
                ))}
              </ul>
              <DemoBanner className="mt-8 max-w-xl" />
            </div>
            <EntryCard initialCode={initialCode} />
          </div>
        </section>

        <HowItWorks />
      </main>

      <footer className="border-t">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>
            {APP_CONFIG.name} — {APP_CONFIG.tagline}
          </p>
          <p>Built for the iStudio self-paced internship.</p>
        </div>
      </footer>
    </div>
  )
}
