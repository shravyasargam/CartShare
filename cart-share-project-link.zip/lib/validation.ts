import { z } from 'zod'
import { APP_CONFIG } from '@/lib/config'

export const displayNameSchema = z
  .string({ error: 'Please enter your name.' })
  .trim()
  .min(2, 'Name must be at least 2 characters.')
  .max(32, 'Name must be 32 characters or fewer.')
  .regex(/^[\p{L}\p{N} .'-]+$/u, 'Name can only contain letters, numbers, spaces, and . \' -')

export const roomNameSchema = z
  .string({ error: 'Please enter a room name.' })
  .trim()
  .min(2, 'Room name must be at least 2 characters.')
  .max(48, 'Room name must be 48 characters or fewer.')

export const roomCodeSchema = z
  .string({ error: 'Please enter a room code.' })
  .trim()
  .toUpperCase()
  .transform((v) => v.replace(/[\s-]/g, ''))
  .pipe(z.string().regex(/^[A-Z0-9]{6}$/, 'Room codes are 6 letters or numbers, e.g. K7PX2Q.'))

export const createRoomSchema = z.object({
  displayName: displayNameSchema,
  roomName: roomNameSchema,
  includeSamples: z.boolean().default(true),
})

export const joinRoomSchema = z.object({
  displayName: displayNameSchema,
  code: roomCodeSchema,
})

export const itemInputSchema = z.object({
  name: z
    .string({ error: 'Please enter a product name.' })
    .trim()
    .min(1, 'Please enter a product name.')
    .max(60, 'Product name must be 60 characters or fewer.'),
  category: z
    .string()
    .trim()
    .max(30, 'Category must be 30 characters or fewer.')
    .nullish()
    .transform((v) => (v ? v : null)),
  quantity: z
    .number({ error: 'Quantity must be a number.' })
    .int('Quantity must be a whole number.')
    .min(1, 'Quantity must be at least 1.')
    .max(APP_CONFIG.maxQuantity, `Quantity cannot exceed ${APP_CONFIG.maxQuantity}.`),
  unitPricePaise: z
    .number({ error: 'Price must be a number.' })
    .int('Price can have at most 2 decimal places.')
    .min(1, 'Price must be greater than ₹0.')
    .max(APP_CONFIG.maxUnitPricePaise, 'Price cannot exceed ₹1,00,000.'),
})

export const itemUpdateSchema = itemInputSchema.extend({
  version: z.number().int().min(1),
})

export const quantityChangeSchema = z.object({
  delta: z.number().int().refine((d) => d !== 0 && Math.abs(d) <= 100, 'Invalid quantity change.'),
})

export type ItemInput = z.infer<typeof itemInputSchema>
