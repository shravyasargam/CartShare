export type ParticipantRole = 'owner' | 'member'

export interface Participant {
  id: string
  name: string
  role: ParticipantRole
  active: boolean
  joinedAt: string
}

export interface CartItem {
  id: string
  name: string
  category: string | null
  quantity: number
  unitPricePaise: number
  addedById: string
  addedByName: string
  updatedByName: string
  createdAt: string
  updatedAt: string
  version: number
}

export type ActivityType =
  | 'room_created'
  | 'member_joined'
  | 'member_left'
  | 'item_added'
  | 'item_updated'
  | 'quantity_changed'
  | 'item_removed'

export interface Activity {
  id: string
  type: ActivityType
  actorName: string
  productName: string | null
  detail: string | null
  createdAt: string
}

export interface Room {
  id: string
  code: string
  name: string
  createdAt: string
}

export interface RoomState {
  mode: 'demo' | 'database'
  room: Room
  me: Participant
  participants: Participant[]
  items: CartItem[]
  activities: Activity[]
  serverTime: string
}
