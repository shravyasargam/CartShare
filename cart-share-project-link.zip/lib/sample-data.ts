import type { ItemInput } from '@/lib/validation'

export const SAMPLE_ITEMS: ItemInput[] = [
  { name: 'Basmati Rice (5 kg)', category: 'Groceries', quantity: 1, unitPricePaise: 64_900 },
  { name: 'Toned Milk (1 L)', category: 'Dairy', quantity: 4, unitPricePaise: 6_200 },
  { name: 'Whole Wheat Bread', category: 'Bakery', quantity: 2, unitPricePaise: 5_500 },
  { name: 'Toor Dal (1 kg)', category: 'Groceries', quantity: 2, unitPricePaise: 16_500 },
  { name: 'Onions (1 kg)', category: 'Produce', quantity: 2, unitPricePaise: 4_500 },
  { name: 'Tomatoes (1 kg)', category: 'Produce', quantity: 2, unitPricePaise: 4_000 },
  { name: 'Bananas (1 dozen)', category: 'Fruits', quantity: 1, unitPricePaise: 6_000 },
  { name: 'Dishwash Liquid (750 ml)', category: 'Household', quantity: 1, unitPricePaise: 19_900 },
]
