/**
 * Central CartShare configuration.
 * All money values are stored as integer paise (1 rupee = 100 paise)
 * to avoid floating-point rounding errors.
 */
export const APP_CONFIG = {
  name: 'CartShare',
  tagline: 'Shop Together. Spend Smarter.',
  currency: 'INR',
  locale: 'en-IN',
  /** Free-delivery threshold: ₹6,000 */
  freeDeliveryThresholdPaise: 600_000,
  /** How often connected clients pull the latest room state (ms). */
  syncIntervalMs: 2_000,
  maxParticipantsPerRoom: 20,
  maxItemsPerRoom: 200,
  maxQuantity: 999,
  maxUnitPricePaise: 10_000_000, // ₹1,00,000
  activityLimit: 100,
} as const

export const PRODUCT_CATEGORIES = [
  'Groceries',
  'Dairy',
  'Bakery',
  'Produce',
  'Fruits',
  'Beverages',
  'Snacks',
  'Household',
  'Personal care',
  'Other',
] as const
