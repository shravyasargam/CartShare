import { APP_CONFIG } from '@/lib/config'

const wholeRupees = new Intl.NumberFormat(APP_CONFIG.locale, {
  style: 'currency',
  currency: APP_CONFIG.currency,
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
})

const withPaise = new Intl.NumberFormat(APP_CONFIG.locale, {
  style: 'currency',
  currency: APP_CONFIG.currency,
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

/** Formats integer paise as INR, e.g. 600000 -> "₹6,000", 6250 -> "₹62.50". */
export function formatINR(paise: number, options: { alwaysShowPaise?: boolean } = {}): string {
  const safe = Number.isFinite(paise) ? Math.round(paise) : 0
  if (!options.alwaysShowPaise && safe % 100 === 0) return wholeRupees.format(safe / 100)
  return withPaise.format(safe / 100)
}

/**
 * Converts a user-typed rupee string ("45", "62.5", "1,299.99") into integer paise.
 * Returns null for invalid, negative, or more-than-two-decimal input.
 * Uses string arithmetic so values like "0.29" never pick up float errors.
 */
export function parseRupeesToPaise(input: string): number | null {
  const cleaned = input.trim().replace(/,/g, '')
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null
  const [rupees, fraction = ''] = cleaned.split('.')
  const paise = Number(rupees) * 100 + Number(fraction.padEnd(2, '0'))
  return Number.isSafeInteger(paise) ? paise : null
}

/** Formats paise as a plain editable rupee string, e.g. 6250 -> "62.50", 4500 -> "45". */
export function paiseToRupeeInput(paise: number): string {
  const rupees = Math.floor(paise / 100)
  const rest = paise % 100
  return rest === 0 ? String(rupees) : `${rupees}.${String(rest).padStart(2, '0')}`
}

export function lineSubtotalPaise(item: { quantity: number; unitPricePaise: number }): number {
  return item.quantity * item.unitPricePaise
}
