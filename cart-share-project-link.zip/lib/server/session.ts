import { randomUUID } from 'node:crypto'
import { cookies } from 'next/headers'

/**
 * Each browser gets a random, server-generated session token in an httpOnly cookie.
 * The server maps this token to room memberships, so clients can never claim
 * to be another participant by sending someone else's ID.
 */
const SESSION_COOKIE = 'cartshare_session'

export async function readSessionToken(): Promise<string | null> {
  const store = await cookies()
  const value = store.get(SESSION_COOKIE)?.value
  return value && /^[0-9a-f-]{36}$/.test(value) ? value : null
}

export async function getOrCreateSessionToken(): Promise<string> {
  const existing = await readSessionToken()
  if (existing) return existing
  const token = randomUUID()
  const store = await cookies()
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    // SameSite=None + Secure keeps the session working inside the embedded preview iframe.
    sameSite: 'none',
    secure: true,
    path: '/',
    maxAge: 60 * 60 * 24 * 30,
  })
  return token
}
