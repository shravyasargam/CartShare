import { randomInt, randomUUID } from 'node:crypto'
import { APP_CONFIG } from '@/lib/config'
import { formatINR } from '@/lib/money'
import { SAMPLE_ITEMS } from '@/lib/sample-data'
import type { Activity, ActivityType, CartItem, Participant, Room, RoomState } from '@/lib/types'
import type { ItemInput } from '@/lib/validation'

/**
 * DEMO-MODE DATA STORE
 * --------------------
 * Supabase is not connected, so room data is kept in this server process's memory.
 * Every browser talks to the same server, so collaboration works across devices,
 * but data resets when the server restarts and is not shared between serverless instances.
 * The Supabase schema in supabase/migrations mirrors these structures 1:1.
 */

export class StoreError extends Error {
  constructor(
    public status: number,
    message: string,
    public payload?: Record<string, unknown>,
  ) {
    super(message)
  }
}

interface ParticipantRecord extends Participant {
  token: string
}

interface RoomRecord {
  room: Room
  participants: ParticipantRecord[]
  items: CartItem[]
  activities: Activity[]
}

const globalStore = globalThis as unknown as { __cartshareRooms?: Map<string, RoomRecord> }
const rooms = (globalStore.__cartshareRooms ??= new Map<string, RoomRecord>())

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

function generateUniqueCode(): string {
  for (let attempt = 0; attempt < 50; attempt++) {
    let code = ''
    for (let i = 0; i < 6; i++) code += CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]
    if (!rooms.has(code)) return code
  }
  throw new StoreError(503, 'Could not generate a unique room code. Please try again.')
}

const now = () => new Date().toISOString()

function publicParticipant({ token: _token, ...p }: ParticipantRecord): Participant {
  return p
}

function toState(record: RoomRecord, me: ParticipantRecord): RoomState {
  return {
    mode: 'demo',
    room: record.room,
    me: publicParticipant(me),
    participants: record.participants.map(publicParticipant),
    items: record.items,
    activities: record.activities,
    serverTime: now(),
  }
}

function log(
  record: RoomRecord,
  actor: ParticipantRecord,
  type: ActivityType,
  productName: string | null = null,
  detail: string | null = null,
) {
  record.activities.unshift({
    id: randomUUID(),
    type,
    actorName: actor.name,
    productName,
    detail,
    createdAt: now(),
  })
  record.activities.length = Math.min(record.activities.length, APP_CONFIG.activityLimit)
}

function findRoom(code: string): RoomRecord {
  const record = rooms.get(code)
  if (!record) {
    throw new StoreError(404, `No room found with code ${code}. Check the code and try again.`, {
      reason: 'room_not_found',
    })
  }
  return record
}

/** Server-side authorization: the caller's httpOnly session token must belong to an active member. */
function requireMember(code: string, token: string | null) {
  const record = findRoom(code)
  const me = token ? record.participants.find((p) => p.token === token && p.active) : undefined
  if (!me) {
    throw new StoreError(403, "You're not a member of this room. Join with the room code to get access.", {
      reason: 'not_member',
    })
  }
  return { record, me }
}

function findItem(record: RoomRecord, itemId: string): CartItem {
  const item = record.items.find((i) => i.id === itemId)
  if (!item) {
    throw new StoreError(404, 'This product was already removed by another participant.', {
      reason: 'item_not_found',
    })
  }
  return item
}

function nameTaken(record: RoomRecord, name: string, exceptToken: string) {
  const lower = name.toLocaleLowerCase()
  return record.participants.some((p) => p.active && p.token !== exceptToken && p.name.toLocaleLowerCase() === lower)
}

function newItem(input: ItemInput, actor: ParticipantRecord): CartItem {
  const timestamp = now()
  return {
    id: randomUUID(),
    name: input.name,
    category: input.category,
    quantity: input.quantity,
    unitPricePaise: input.unitPricePaise,
    addedById: actor.id,
    addedByName: actor.name,
    updatedByName: actor.name,
    createdAt: timestamp,
    updatedAt: timestamp,
    version: 1,
  }
}

export function createRoom(
  input: { displayName: string; roomName: string; includeSamples: boolean },
  token: string,
): { code: string } {
  const code = generateUniqueCode()
  const owner: ParticipantRecord = {
    id: randomUUID(),
    name: input.displayName,
    role: 'owner',
    active: true,
    joinedAt: now(),
    token,
  }
  const record: RoomRecord = {
    room: { id: randomUUID(), code, name: input.roomName, createdAt: now() },
    participants: [owner],
    items: [],
    activities: [],
  }
  log(record, owner, 'room_created', null, input.roomName)
  if (input.includeSamples) {
    record.items.push(...SAMPLE_ITEMS.map((item) => newItem(item, owner)))
    log(record, owner, 'item_added', null, `${SAMPLE_ITEMS.length} sample products`)
  }
  rooms.set(code, record)
  return { code }
}

export function joinRoom(input: { displayName: string; code: string }, token: string) {
  const record = findRoom(input.code)
  const existing = record.participants.find((p) => p.token === token)

  if (existing?.active) return { code: input.code, alreadyMember: true }

  if (nameTaken(record, input.displayName, token)) {
    throw new StoreError(409, `Someone in this room is already called "${input.displayName}". Try a different name.`)
  }
  const activeCount = record.participants.filter((p) => p.active).length
  if (activeCount >= APP_CONFIG.maxParticipantsPerRoom) {
    throw new StoreError(409, 'This room is full.')
  }

  if (existing) {
    existing.active = true
    existing.name = input.displayName
    existing.joinedAt = now()
    log(record, existing, 'member_joined', null, 'rejoined the room')
  } else {
    const member: ParticipantRecord = {
      id: randomUUID(),
      name: input.displayName,
      role: activeCount === 0 ? 'owner' : 'member',
      active: true,
      joinedAt: now(),
      token,
    }
    record.participants.push(member)
    log(record, member, 'member_joined')
  }
  return { code: input.code, alreadyMember: false }
}

export function getRoomState(code: string, token: string | null): RoomState {
  const { record, me } = requireMember(code, token)
  return toState(record, me)
}

export function addItem(code: string, token: string | null, input: ItemInput): RoomState {
  const { record, me } = requireMember(code, token)
  if (record.items.length >= APP_CONFIG.maxItemsPerRoom) {
    throw new StoreError(409, `A room can hold up to ${APP_CONFIG.maxItemsPerRoom} products.`)
  }
  const item = newItem(input, me)
  record.items.push(item)
  log(record, me, 'item_added', item.name, `${item.quantity} × ${formatINR(item.unitPricePaise)}`)
  return toState(record, me)
}

export function updateItem(
  code: string,
  token: string | null,
  itemId: string,
  input: ItemInput & { version: number },
): RoomState {
  const { record, me } = requireMember(code, token)
  const item = findItem(record, itemId)

  // Optimistic concurrency: reject edits based on an outdated copy instead of overwriting newer changes.
  if (item.version !== input.version) {
    throw new StoreError(
      409,
      `${item.updatedByName} changed "${item.name}" while you were editing. We loaded the latest version.`,
      { reason: 'version_conflict', state: toState(record, me) },
    )
  }

  const changes: string[] = []
  if (item.name !== input.name) changes.push(`renamed from "${item.name}"`)
  if (item.quantity !== input.quantity) changes.push(`qty ${item.quantity} → ${input.quantity}`)
  if (item.unitPricePaise !== input.unitPricePaise)
    changes.push(`price ${formatINR(item.unitPricePaise)} → ${formatINR(input.unitPricePaise)}`)
  if (item.category !== input.category) changes.push(`category → ${input.category ?? 'none'}`)
  if (changes.length === 0) return toState(record, me)

  Object.assign(item, {
    name: input.name,
    category: input.category,
    quantity: input.quantity,
    unitPricePaise: input.unitPricePaise,
    updatedByName: me.name,
    updatedAt: now(),
    version: item.version + 1,
  })
  log(record, me, 'item_updated', item.name, changes.join(', '))
  return toState(record, me)
}

/** Atomic relative change, so two people pressing "+" at once both count. */
export function changeQuantity(code: string, token: string | null, itemId: string, delta: number): RoomState {
  const { record, me } = requireMember(code, token)
  const item = findItem(record, itemId)
  const next = item.quantity + delta
  if (next < 1) throw new StoreError(400, 'Quantity must be at least 1. Use remove to delete the product.')
  if (next > APP_CONFIG.maxQuantity) throw new StoreError(400, `Quantity cannot exceed ${APP_CONFIG.maxQuantity}.`)
  const previous = item.quantity
  Object.assign(item, { quantity: next, updatedByName: me.name, updatedAt: now(), version: item.version + 1 })
  log(record, me, 'quantity_changed', item.name, `${previous} → ${next}`)
  return toState(record, me)
}

export function removeItem(code: string, token: string | null, itemId: string): RoomState {
  const { record, me } = requireMember(code, token)
  const item = findItem(record, itemId)
  record.items = record.items.filter((i) => i.id !== itemId)
  log(record, me, 'item_removed', item.name)
  return toState(record, me)
}

export function leaveRoom(code: string, token: string | null) {
  const { record, me } = requireMember(code, token)
  me.active = false
  let detail: string | null = null
  if (me.role === 'owner') {
    me.role = 'member'
    const successor = record.participants
      .filter((p) => p.active)
      .sort((a, b) => a.joinedAt.localeCompare(b.joinedAt))[0]
    if (successor) {
      successor.role = 'owner'
      detail = `ownership passed to ${successor.name}`
    }
  }
  log(record, me, 'member_left', null, detail)
  return { ok: true }
}
