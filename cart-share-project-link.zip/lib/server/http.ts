import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { roomCodeSchema } from '@/lib/validation'
import { StoreError } from '@/lib/server/store'

export async function handle(fn: () => unknown | Promise<unknown>) {
  try {
    return NextResponse.json(await fn(), { headers: { 'Cache-Control': 'no-store' } })
  } catch (error) {
    if (error instanceof StoreError) {
      return NextResponse.json({ error: error.message, ...error.payload }, { status: error.status })
    }
    if (error instanceof ZodError) {
      return NextResponse.json({ error: error.issues[0]?.message ?? 'Invalid input.' }, { status: 400 })
    }
    console.error('[cartshare] Unexpected API error', error)
    return NextResponse.json({ error: 'Something went wrong on our side. Please try again.' }, { status: 500 })
  }
}

export async function readJson(request: Request): Promise<unknown> {
  try {
    return await request.json()
  } catch {
    throw new StoreError(400, 'Request body must be valid JSON.')
  }
}

export function parseCode(raw: string): string {
  return roomCodeSchema.parse(raw)
}
