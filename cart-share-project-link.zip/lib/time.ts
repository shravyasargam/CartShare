const relative = new Intl.RelativeTimeFormat('en-IN', { numeric: 'auto' })
const exact = new Intl.DateTimeFormat('en-IN', {
  dateStyle: 'medium',
  timeStyle: 'short',
})

export function formatExact(iso: string): string {
  return exact.format(new Date(iso))
}

export function formatRelative(iso: string, now: number = Date.now()): string {
  const diffSeconds = Math.round((new Date(iso).getTime() - now) / 1000)
  const abs = Math.abs(diffSeconds)
  if (abs < 45) return 'just now'
  if (abs < 3600) return relative.format(Math.round(diffSeconds / 60), 'minute')
  if (abs < 86400) return relative.format(Math.round(diffSeconds / 3600), 'hour')
  if (abs < 604800) return relative.format(Math.round(diffSeconds / 86400), 'day')
  return formatExact(iso)
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  const letters = parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : (parts[0] ?? '?').slice(0, 2)
  return letters.toUpperCase()
}
