import { APP_CONFIG } from '@/lib/config'
import { lineSubtotalPaise } from '@/lib/money'
import type { CartItem, Participant } from '@/lib/types'

export interface CartTotals {
  uniqueProducts: number
  totalUnits: number
  totalPaise: number
}

export function computeCartTotals(items: Pick<CartItem, 'quantity' | 'unitPricePaise'>[]): CartTotals {
  return items.reduce<CartTotals>(
    (acc, item) => ({
      uniqueProducts: acc.uniqueProducts + 1,
      totalUnits: acc.totalUnits + item.quantity,
      totalPaise: acc.totalPaise + lineSubtotalPaise(item),
    }),
    { uniqueProducts: 0, totalUnits: 0, totalPaise: 0 },
  )
}

export interface DeliveryStatus {
  thresholdPaise: number
  remainingPaise: number
  percent: number
  reached: boolean
}

export function computeDeliveryStatus(
  totalPaise: number,
  thresholdPaise: number = APP_CONFIG.freeDeliveryThresholdPaise,
): DeliveryStatus {
  const safeTotal = Number.isFinite(totalPaise) ? Math.max(0, totalPaise) : 0
  const safeThreshold = Number.isFinite(thresholdPaise) ? Math.max(0, thresholdPaise) : 0
  if (safeThreshold === 0) {
    return { thresholdPaise: 0, remainingPaise: 0, percent: 100, reached: true }
  }
  const percent = Math.min(100, Math.max(0, (safeTotal / safeThreshold) * 100))
  return {
    thresholdPaise: safeThreshold,
    remainingPaise: Math.max(0, safeThreshold - safeTotal),
    percent: Math.round(percent * 10) / 10,
    reached: safeTotal >= safeThreshold,
  }
}

export interface Contribution {
  participantId: string
  name: string
  active: boolean
  products: number
  units: number
  totalPaise: number
  sharePercent: number
}

export function computeContributions(items: CartItem[], participants: Participant[]): Contribution[] {
  const byId = new Map<string, Contribution>()
  for (const p of participants) {
    byId.set(p.id, {
      participantId: p.id,
      name: p.name,
      active: p.active,
      products: 0,
      units: 0,
      totalPaise: 0,
      sharePercent: 0,
    })
  }
  for (const item of items) {
    const entry =
      byId.get(item.addedById) ??
      ({
        participantId: item.addedById,
        name: item.addedByName,
        active: false,
        products: 0,
        units: 0,
        totalPaise: 0,
        sharePercent: 0,
      } satisfies Contribution)
    entry.products += 1
    entry.units += item.quantity
    entry.totalPaise += lineSubtotalPaise(item)
    byId.set(item.addedById, entry)
  }
  const grandTotal = items.reduce((sum, i) => sum + lineSubtotalPaise(i), 0)
  return [...byId.values()]
    .filter((c) => c.active || c.products > 0)
    .map((c) => ({
      ...c,
      sharePercent: grandTotal > 0 ? Math.round((c.totalPaise / grandTotal) * 1000) / 10 : 0,
    }))
    .sort((a, b) => b.totalPaise - a.totalPaise || a.name.localeCompare(b.name))
}
