import Link from 'next/link'
import { FlaskConical } from 'lucide-react'
import { cn } from '@/lib/utils'

export function DemoBanner({ className }: { className?: string }) {
  return (
    <div
      role="note"
      className={cn(
        'no-print flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950',
        className,
      )}
    >
      <FlaskConical className="mt-0.5 size-4 shrink-0 text-amber-700" aria-hidden="true" />
      <p className="text-pretty leading-relaxed">
        <strong className="font-semibold">Demo mode.</strong> Supabase is not connected, so rooms are kept in the
        server&apos;s memory. Sharing works across browsers, but data resets when the server restarts.{' '}
        <Link href="/about#database" className="font-medium underline underline-offset-2 hover:text-amber-800">
          How to connect a real database
        </Link>
      </p>
    </div>
  )
}
