'use client'

import { RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { SyncStatus } from '@/hooks/use-room'
import { cn } from '@/lib/utils'

const LABELS: Record<SyncStatus, string> = {
  connecting: 'Connecting',
  connected: 'Live',
  disconnected: 'Offline',
}

export function SyncIndicator({
  status,
  onRefresh,
  refreshing,
}: {
  status: SyncStatus
  onRefresh: () => void
  refreshing: boolean
}) {
  return (
    <div className="flex items-center gap-1">
      <span
        role="status"
        aria-live="polite"
        className={cn(
          'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium',
          status === 'connected' && 'border-emerald-200 bg-emerald-50 text-emerald-800',
          status === 'connecting' && 'border-amber-200 bg-amber-50 text-amber-900',
          status === 'disconnected' && 'border-red-200 bg-red-50 text-red-800',
        )}
      >
        <span className="relative flex size-2">
          {status === 'connected' && (
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-60 motion-reduce:hidden" />
          )}
          <span
            className={cn(
              'relative inline-flex size-2 rounded-full',
              status === 'connected' && 'bg-emerald-500',
              status === 'connecting' && 'bg-amber-500',
              status === 'disconnected' && 'bg-red-500',
            )}
          />
        </span>
        <span>
          <span className="sr-only">Sync status: </span>
          {LABELS[status]}
        </span>
      </span>
      <Button variant="ghost" size="icon-sm" onClick={onRefresh} aria-label="Refresh room data">
        <RefreshCw className={cn(refreshing && 'animate-spin')} aria-hidden="true" />
      </Button>
    </div>
  )
}
