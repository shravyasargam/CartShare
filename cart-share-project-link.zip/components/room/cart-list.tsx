'use client'

import { useMemo, useState } from 'react'
import { Minus, Pencil, Plus, Search, ShoppingCart, Trash2, X } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { APP_CONFIG } from '@/lib/config'
import { formatINR, lineSubtotalPaise } from '@/lib/money'
import { formatExact, formatRelative } from '@/lib/time'
import type { CartItem } from '@/lib/types'
import { cn } from '@/lib/utils'

const ALL = 'All'

export function CartList({
  items,
  onAdd,
  onEdit,
  onRemove,
  onChangeQuantity,
}: {
  items: CartItem[]
  onAdd: () => void
  onEdit: (item: CartItem) => void
  onRemove: (item: CartItem) => void
  onChangeQuantity: (item: CartItem, delta: number) => Promise<boolean>
}) {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState<string>(ALL)
  const [pendingId, setPendingId] = useState<string | null>(null)

  const categories = useMemo(() => {
    const set = new Set(items.map((i) => i.category ?? 'Uncategorised'))
    return [ALL, ...Array.from(set).sort()]
  }, [items])

  const activeCategory = categories.includes(category) ? category : ALL

  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase()
    return items.filter((item) => {
      const cat = item.category ?? 'Uncategorised'
      if (activeCategory !== ALL && cat !== activeCategory) return false
      if (!q) return true
      return item.name.toLocaleLowerCase().includes(q) || cat.toLocaleLowerCase().includes(q)
    })
  }, [items, query, activeCategory])

  async function bump(item: CartItem, delta: number) {
    setPendingId(item.id)
    await onChangeQuantity(item, delta)
    setPendingId(null)
  }

  return (
    <section id="cart" aria-labelledby="cart-heading" className="scroll-mt-20 rounded-2xl border bg-card shadow-xs">
      <div className="flex flex-col gap-3 border-b p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 id="cart-heading" className="font-semibold">
              Shared cart
            </h2>
            <p className="text-sm text-muted-foreground">Everyone in the room can add, edit, and remove products.</p>
          </div>
          <Button onClick={onAdd} className="h-9">
            <Plus aria-hidden="true" />
            <span className="hidden sm:inline">Add product</span>
            <span className="sm:hidden">Add</span>
          </Button>
        </div>

        {items.length > 0 && (
          <div className="flex flex-col gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <Input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by product or category"
                aria-label="Search products"
                className="h-9 pl-9"
              />
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1" role="group" aria-label="Filter by category">
              {categories.map((c) => (
                <button
                  key={c}
                  type="button"
                  aria-pressed={activeCategory === c}
                  onClick={() => setCategory(c)}
                  className={cn(
                    'shrink-0 rounded-full border px-3 py-1 text-xs font-medium transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50',
                    activeCategory === c
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'bg-card text-muted-foreground hover:bg-muted hover:text-foreground',
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {items.length === 0 ? (
        <div className="flex flex-col items-center px-6 py-14 text-center">
          <span className="inline-flex size-12 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground">
            <ShoppingCart className="size-6" aria-hidden="true" />
          </span>
          <h3 className="mt-4 font-semibold">Your shared cart is empty</h3>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground text-pretty">
            Add the first product. Everyone in this room will see it instantly, along with your name.
          </p>
          <Button onClick={onAdd} className="mt-5">
            <Plus aria-hidden="true" />
            Add the first product
          </Button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center px-6 py-10 text-center">
          <p className="font-medium">No products match your search</p>
          <Button
            variant="ghost"
            className="mt-2"
            onClick={() => {
              setQuery('')
              setCategory(ALL)
            }}
          >
            <X aria-hidden="true" />
            Clear filters
          </Button>
        </div>
      ) : (
        <ul className="divide-y">
          {filtered.map((item) => (
            <li key={item.id} className="flex flex-col gap-3 p-4 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center sm:px-5">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate font-medium">{item.name}</p>
                  {item.category && <Badge variant="secondary">{item.category}</Badge>}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {formatINR(item.unitPricePaise)} each · added by{' '}
                  <span className="font-medium text-foreground">{item.addedByName}</span> ·{' '}
                  <time dateTime={item.updatedAt} title={`Created ${formatExact(item.createdAt)} · Updated ${formatExact(item.updatedAt)}`}>
                    {item.version > 1 ? `edited ${formatRelative(item.updatedAt)} by ${item.updatedByName}` : formatRelative(item.createdAt)}
                  </time>
                </p>
              </div>

              <div className="flex items-center justify-between gap-3 sm:justify-end">
                <div className="flex items-center rounded-lg border" role="group" aria-label={`Quantity of ${item.name}`}>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => bump(item, -1)}
                    disabled={item.quantity <= 1 || pendingId === item.id}
                    aria-label={`Decrease quantity of ${item.name}`}
                  >
                    <Minus aria-hidden="true" />
                  </Button>
                  <span className="min-w-8 text-center text-sm font-semibold tabular-nums" aria-live="polite">
                    {item.quantity}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => bump(item, 1)}
                    disabled={item.quantity >= APP_CONFIG.maxQuantity || pendingId === item.id}
                    aria-label={`Increase quantity of ${item.name}`}
                  >
                    <Plus aria-hidden="true" />
                  </Button>
                </div>
                <p className="w-24 text-right font-semibold tabular-nums">{formatINR(lineSubtotalPaise(item))}</p>
                <div className="flex items-center">
                  <Button variant="ghost" size="icon-sm" onClick={() => onEdit(item)} aria-label={`Edit ${item.name}`}>
                    <Pencil aria-hidden="true" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => onRemove(item)}
                    aria-label={`Remove ${item.name}`}
                    className="text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 aria-hidden="true" />
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
