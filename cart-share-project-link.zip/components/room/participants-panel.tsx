import { Crown } from 'lucide-react'
import { Avatar } from '@/components/room/avatar'
import type { Contribution } from '@/lib/cart-math'
import { formatINR } from '@/lib/money'
import type { Participant } from '@/lib/types'

export function ParticipantsPanel({
  participants,
  contributions,
  meId,
}: {
  participants: Participant[]
  contributions: Contribution[]
  meId: string
}) {
  const byId = new Map(contributions.map((c) => [c.participantId, c]))
  const active = participants.filter((p) => p.active)
  const formerContributors = contributions.filter((c) => !c.active && c.products > 0)

  return (
    <section id="people" aria-labelledby="people-heading" className="scroll-mt-20 rounded-2xl border bg-card shadow-xs">
      <div className="flex items-center justify-between border-b p-4">
        <h2 id="people-heading" className="font-semibold">
          Participants & contributions
        </h2>
        <span className="text-xs text-muted-foreground">{active.length} in room</span>
      </div>
      <ul className="flex flex-col gap-1 p-2">
        {active.map((p) => {
          const c = byId.get(p.id)
          return (
            <ContributionRow
              key={p.id}
              name={p.name}
              isMe={p.id === meId}
              isOwner={p.role === 'owner'}
              contribution={c}
            />
          )
        })}
        {formerContributors.map((c) => (
          <ContributionRow key={c.participantId} name={c.name} former contribution={c} />
        ))}
      </ul>
    </section>
  )
}

function ContributionRow({
  name,
  isMe,
  isOwner,
  former,
  contribution,
}: {
  name: string
  isMe?: boolean
  isOwner?: boolean
  former?: boolean
  contribution?: Contribution
}) {
  const share = Math.min(100, Math.max(0, contribution?.sharePercent ?? 0))
  return (
    <li className="rounded-lg p-2">
      <div className="flex items-center gap-3">
        <Avatar name={name} className={former ? 'opacity-60' : undefined} />
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 truncate text-sm font-medium">
            {name}
            {isMe && <span className="text-xs font-normal text-muted-foreground">(you)</span>}
            {isOwner && (
              <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">
                <Crown className="size-3" aria-hidden="true" />
                Owner
              </span>
            )}
            {former && <span className="text-xs font-normal text-muted-foreground">(left)</span>}
          </p>
          <p className="text-xs text-muted-foreground">
            {contribution?.products ?? 0} products · {contribution?.units ?? 0} units
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm font-semibold tabular-nums">{formatINR(contribution?.totalPaise ?? 0)}</p>
          <p className="text-xs text-muted-foreground tabular-nums">{share.toFixed(0)}%</p>
        </div>
      </div>
      <div className="mt-2 ml-11 h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden="true">
        <div className="h-full rounded-full bg-primary/80 transition-[width] duration-500" style={{ width: `${share}%` }} />
      </div>
    </li>
  )
}
