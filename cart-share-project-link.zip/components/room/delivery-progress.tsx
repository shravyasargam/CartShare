import { PartyPopper, Truck } from 'lucide-react'
import type { DeliveryStatus } from '@/lib/cart-math'
import { formatINR } from '@/lib/money'

export function DeliveryProgress({ delivery, totalPaise }: { delivery: DeliveryStatus; totalPaise: number }) {
  const percent = Math.min(100, Math.max(0, delivery.percent))
  return (
    <section aria-labelledby="delivery-heading" className="rounded-2xl border bg-card p-4 shadow-xs sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span
            className={`inline-flex size-9 shrink-0 items-center justify-center rounded-lg ${delivery.reached ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}
          >
            {delivery.reached ? <PartyPopper className="size-4" aria-hidden="true" /> : <Truck className="size-4" aria-hidden="true" />}
          </span>
          <div>
            <h2 id="delivery-heading" className="font-semibold">
              {delivery.reached ? 'Free delivery unlocked!' : 'Free delivery progress'}
            </h2>
            <p className="text-sm text-muted-foreground" aria-live="polite">
              {delivery.reached
                ? `Your cart is ${formatINR(totalPaise - delivery.thresholdPaise)} over the ${formatINR(delivery.thresholdPaise)} threshold.`
                : `Add ${formatINR(delivery.remainingPaise)} more to reach ${formatINR(delivery.thresholdPaise)}.`}
            </p>
          </div>
        </div>
        <p className="font-mono text-sm font-medium tabular-nums">{percent.toFixed(0)}%</p>
      </div>
      <div
        role="progressbar"
        aria-label="Progress towards free delivery"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(percent)}
        aria-valuetext={`${formatINR(totalPaise)} of ${formatINR(delivery.thresholdPaise)}`}
        className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-muted"
      >
        <div
          className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-primary transition-[width] duration-500 ease-out"
          style={{ width: `${percent}%` }}
        />
      </div>
      <div className="mt-2 flex justify-between text-xs text-muted-foreground tabular-nums">
        <span>{formatINR(totalPaise)}</span>
        <span>{formatINR(delivery.thresholdPaise)}</span>
      </div>
    </section>
  )
}
