'use client'

import { useState } from 'react'
import { Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { APP_CONFIG, PRODUCT_CATEGORIES } from '@/lib/config'
import { formatINR, lineSubtotalPaise, paiseToRupeeInput, parseRupeesToPaise } from '@/lib/money'
import type { CartItem } from '@/lib/types'
import { itemInputSchema, type ItemInput } from '@/lib/validation'

export function ItemDialog({
  open,
  onOpenChange,
  item,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  item?: CartItem
  onSubmit: (input: ItemInput) => Promise<boolean>
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{item ? 'Edit product' : 'Add a product'}</DialogTitle>
          <DialogDescription>
            {item
              ? `Last updated by ${item.updatedByName}. Changes are visible to everyone in the room.`
              : 'Everyone in the room will see this product and that you added it.'}
          </DialogDescription>
        </DialogHeader>
        {/* Remount on version change so the form always starts from the latest saved values. */}
        <ItemForm key={item ? `${item.id}-${item.version}` : 'new'} item={item} onSubmit={onSubmit} onCancel={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  )
}

function ItemForm({
  item,
  onSubmit,
  onCancel,
}: {
  item?: CartItem
  onSubmit: (input: ItemInput) => Promise<boolean>
  onCancel: () => void
}) {
  const [name, setName] = useState(item?.name ?? '')
  const [category, setCategory] = useState(item?.category ?? '')
  const [quantity, setQuantity] = useState(String(item?.quantity ?? 1))
  const [price, setPrice] = useState(item ? paiseToRupeeInput(item.unitPricePaise) : '')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  const pricePaise = parseRupeesToPaise(price)
  const qty = Number(quantity)
  const preview =
    pricePaise !== null && Number.isInteger(qty) && qty > 0 ? lineSubtotalPaise({ quantity: qty, unitPricePaise: pricePaise }) : null

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const next: Record<string, string> = {}
    if (pricePaise === null) next.price = 'Enter a valid price, e.g. 49 or 49.50.'
    const parsed = itemInputSchema.safeParse({
      name,
      category: category || null,
      quantity: qty,
      unitPricePaise: pricePaise ?? 0,
    })
    if (!parsed.success) {
      for (const issue of parsed.error.issues) {
        const field = issue.path[0] === 'unitPricePaise' ? 'price' : String(issue.path[0])
        next[field] ??= issue.message
      }
    }
    setErrors(next)
    if (Object.keys(next).length > 0 || !parsed.success) return
    setSaving(true)
    const ok = await onSubmit(parsed.data)
    setSaving(false)
    if (ok) onCancel()
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="item-name">Product name</Label>
        <Input
          id="item-name"
          autoFocus
          value={name}
          maxLength={60}
          placeholder="e.g. Basmati rice 5 kg"
          onChange={(e) => setName(e.target.value)}
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? 'item-name-error' : undefined}
          className="h-10"
        />
        {errors.name && <p id="item-name-error" className="text-xs text-destructive">{errors.name}</p>}
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="item-category">
          Category <span className="font-normal text-muted-foreground">(optional)</span>
        </Label>
        <select
          id="item-category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="h-10 rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
        >
          <option value="">No category</option>
          {PRODUCT_CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        {errors.category && <p className="text-xs text-destructive">{errors.category}</p>}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="item-qty">Quantity</Label>
          <Input
            id="item-qty"
            type="number"
            inputMode="numeric"
            min={1}
            max={APP_CONFIG.maxQuantity}
            step={1}
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            aria-invalid={Boolean(errors.quantity)}
            aria-describedby={errors.quantity ? 'item-qty-error' : undefined}
            className="h-10 tabular-nums"
          />
          {errors.quantity && <p id="item-qty-error" className="text-xs text-destructive">{errors.quantity}</p>}
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="item-price">Unit price (₹)</Label>
          <Input
            id="item-price"
            inputMode="decimal"
            placeholder="0.00"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            aria-invalid={Boolean(errors.price)}
            aria-describedby={errors.price ? 'item-price-error' : undefined}
            className="h-10 tabular-nums"
          />
          {errors.price && <p id="item-price-error" className="text-xs text-destructive">{errors.price}</p>}
        </div>
      </div>

      <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2.5 text-sm">
        <span className="text-muted-foreground">Line subtotal</span>
        <span className="font-semibold tabular-nums">{preview === null ? '—' : formatINR(preview)}</span>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel} disabled={saving}>
          Cancel
        </Button>
        <Button type="submit" disabled={saving}>
          {saving && <Loader2 className="animate-spin" aria-hidden="true" />}
          {item ? 'Save changes' : 'Add to cart'}
        </Button>
      </DialogFooter>
    </form>
  )
}
