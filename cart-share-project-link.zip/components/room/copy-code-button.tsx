'use client'

import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'

export function CopyCodeButton({
  code,
  variant = 'outline',
  label = 'Copy invite code',
  compact = false,
}: {
  code: string
  variant?: 'outline' | 'default' | 'secondary' | 'ghost'
  label?: string
  compact?: boolean
}) {
  const [copied, setCopied] = useState(false)

  async function copy() {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      toast.success(`Invite code ${code} copied`)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error(`Could not access the clipboard. The code is ${code}.`)
    }
  }

  return (
    <Button
      type="button"
      variant={variant}
      size={compact ? 'icon' : 'default'}
      onClick={copy}
      aria-label={compact ? label : undefined}
    >
      {copied ? <Check className="text-primary" aria-hidden="true" /> : <Copy aria-hidden="true" />}
      {!compact && (copied ? 'Copied!' : label)}
    </Button>
  )
}
