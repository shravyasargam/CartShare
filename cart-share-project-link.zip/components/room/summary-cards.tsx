import { Boxes, IndianRupee, Package, Truck } from 'lucide-react'
import type { CartTotals, DeliveryStatus } from '@/lib/cart-math'
import { formatINR } from '@/lib/money'

export function SummaryCards({ totals, delivery }: { totals: CartTotals; delivery: DeliveryStatus }) {
  const cards = [
    { label: 'Unique products', value: totals.uniqueProducts.toLocaleString('en-IN'), icon: Package },
    { label: 'Total quantity', value: totals.totalUnits.toLocaleString('en-IN'), icon: Boxes },
    { label: 'Cart value', value: formatINR(totals.totalPaise), icon: IndianRupee },
    {
      label: 'To free delivery',
      value: delivery.reached ? 'Unlocked' : formatINR(delivery.remainingPaise),
      icon: Truck,
      highlight: delivery.reached,
    },
  ]
  return (
    <section aria-label="Cart summary" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {cards.map((card) => (
        <div key={card.label} className="rounded-2xl border bg-card p-4 shadow-xs">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium text-muted-foreground sm:text-sm">{card.label}</p>
            <span className="inline-flex size-8 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
              <card.icon className="size-4" aria-hidden="true" />
            </span>
          </div>
          <p
            className={`mt-2 text-xl font-semibold tabular-nums tracking-tight sm:text-2xl ${card.highlight ? 'text-primary' : ''}`}
          >
            {card.value}
          </p>
        </div>
      ))}
    </section>
  )
}
