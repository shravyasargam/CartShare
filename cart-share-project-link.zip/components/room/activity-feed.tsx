import { History, LogIn, LogOut, Minus, Pencil, Plus, Sparkles, Trash2 } from 'lucide-react'
import { formatExact, formatRelative } from '@/lib/time'
import type { Activity, ActivityType } from '@/lib/types'

const META: Record<ActivityType, { icon: typeof Plus; verb: string; tone: string }> = {
  room_created: { icon: Sparkles, verb: 'created the room', tone: 'bg-emerald-50 text-emerald-700' },
  member_joined: { icon: LogIn, verb: 'joined the room', tone: 'bg-sky-50 text-sky-700' },
  member_left: { icon: LogOut, verb: 'left the room', tone: 'bg-slate-100 text-slate-700' },
  item_added: { icon: Plus, verb: 'added', tone: 'bg-emerald-50 text-emerald-700' },
  item_updated: { icon: Pencil, verb: 'edited', tone: 'bg-indigo-50 text-indigo-700' },
  quantity_changed: { icon: Minus, verb: 'changed quantity of', tone: 'bg-amber-50 text-amber-800' },
  item_removed: { icon: Trash2, verb: 'removed', tone: 'bg-red-50 text-red-700' },
}

export function ActivityFeed({ activities, now }: { activities: Activity[]; now: number }) {
  return (
    <section id="activity" aria-labelledby="activity-heading" className="scroll-mt-20 rounded-2xl border bg-card shadow-xs">
      <div className="flex items-center justify-between border-b p-4">
        <h2 id="activity-heading" className="font-semibold">
          Recent activity
        </h2>
        <span className="text-xs text-muted-foreground">{activities.length} events</span>
      </div>
      {activities.length === 0 ? (
        <div className="flex flex-col items-center px-6 py-10 text-center text-sm text-muted-foreground">
          <History className="size-6" aria-hidden="true" />
          <p className="mt-2">No activity yet.</p>
        </div>
      ) : (
        <ol className="max-h-[26rem] overflow-y-auto p-2" aria-live="polite" aria-relevant="additions">
          {activities.map((a) => {
            const meta = META[a.type]
            return (
              <li key={a.id} className="flex gap-3 rounded-lg p-2">
                <span className={`mt-0.5 inline-flex size-7 shrink-0 items-center justify-center rounded-full ${meta.tone}`}>
                  <meta.icon className="size-3.5" aria-hidden="true" />
                </span>
                <div className="min-w-0 text-sm">
                  <p className="text-pretty leading-snug">
                    <span className="font-medium">{a.actorName}</span> {meta.verb}
                    {a.productName && <span className="font-medium"> {a.productName}</span>}
                  </p>
                  {a.detail && <p className="text-xs text-muted-foreground">{a.detail}</p>}
                  <time dateTime={a.createdAt} title={formatExact(a.createdAt)} className="text-xs text-muted-foreground">
                    {formatRelative(a.createdAt, now)}
                  </time>
                </div>
              </li>
            )
          })}
        </ol>
      )}
    </section>
  )
}
