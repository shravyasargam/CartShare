'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Activity, Info, LogOut, PanelLeftClose, PanelLeftOpen, Printer, ShoppingCart, Users } from 'lucide-react'
import { BrandLogo, BrandMark } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function RoomShell({
  code,
  header,
  onLeave,
  children,
}: {
  code: string
  header: React.ReactNode
  onLeave: () => void
  children: React.ReactNode
}) {
  const [collapsed, setCollapsed] = useState(false)
  const nav = [
    { href: '#cart', label: 'Shared cart', icon: ShoppingCart },
    { href: '#activity', label: 'Activity', icon: Activity },
    { href: '#people', label: 'People', icon: Users },
    { href: `/room/${code}/receipt`, label: 'Receipt', icon: Printer },
  ]

  return (
    <div className="flex min-h-dvh">
      <aside
        aria-label="Room navigation"
        className={cn(
          'sticky top-0 hidden h-dvh shrink-0 flex-col border-r bg-sidebar transition-[width] duration-200 md:flex',
          collapsed ? 'w-16' : 'w-60',
        )}
      >
        <div className={cn('flex h-16 items-center border-b px-3', collapsed ? 'justify-center' : 'justify-between')}>
          {collapsed ? (
            <Link href="/" aria-label="CartShare home">
              <BrandMark />
            </Link>
          ) : (
            <BrandLogo />
          )}
        </div>
        <nav className="flex flex-1 flex-col gap-1 p-2">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              title={collapsed ? item.label : undefined}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
                collapsed && 'justify-center px-0',
              )}
            >
              <item.icon className="size-4 shrink-0" aria-hidden="true" />
              <span className={cn(collapsed && 'sr-only')}>{item.label}</span>
            </Link>
          ))}
          <Link
            href="/about"
            title={collapsed ? 'About' : undefined}
            className={cn(
              'mt-auto flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/80 hover:bg-sidebar-accent',
              collapsed && 'justify-center px-0',
            )}
          >
            <Info className="size-4 shrink-0" aria-hidden="true" />
            <span className={cn(collapsed && 'sr-only')}>About</span>
          </Link>
          <button
            type="button"
            onClick={onLeave}
            title={collapsed ? 'Leave room' : undefined}
            className={cn(
              'flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-medium text-destructive hover:bg-destructive/10',
              collapsed && 'justify-center px-0',
            )}
          >
            <LogOut className="size-4 shrink-0" aria-hidden="true" />
            <span className={cn(collapsed && 'sr-only')}>Leave room</span>
          </button>
        </nav>
        <div className="border-t p-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-full"
            onClick={() => setCollapsed((c) => !c)}
            aria-expanded={!collapsed}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <PanelLeftOpen aria-hidden="true" /> : <PanelLeftClose aria-hidden="true" />}
            {!collapsed && 'Collapse'}
          </Button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
        {header}
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-5 sm:px-6 sm:py-6">{children}</main>
      </div>

      <nav
        aria-label="Room navigation"
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
      >
        {nav.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium text-muted-foreground hover:text-foreground"
          >
            <item.icon className="size-5" aria-hidden="true" />
            {item.label.replace('Shared ', '')}
          </Link>
        ))}
        <button
          type="button"
          onClick={onLeave}
          className="flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium text-destructive"
        >
          <LogOut className="size-5" aria-hidden="true" />
          Leave
        </button>
      </nav>
    </div>
  )
}
