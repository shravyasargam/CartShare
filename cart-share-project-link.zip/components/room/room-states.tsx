import Link from 'next/link'
import { SearchX, ShieldAlert } from 'lucide-react'
import { BrandLogo } from '@/components/brand'
import { Skeleton } from '@/components/ui/skeleton'
import { EntryCard } from '@/components/welcome/entry-card'
import { Button } from '@/components/ui/button'

export function RoomLoading() {
  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-4 py-6 sm:px-6" aria-busy="true" aria-label="Loading room">
      <Skeleton className="h-10 w-64" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
      <Skeleton className="h-28 rounded-2xl" />
      <div className="grid gap-4 lg:grid-cols-[1fr_22rem]">
        <Skeleton className="h-96 rounded-2xl" />
        <Skeleton className="h-96 rounded-2xl" />
      </div>
    </div>
  )
}

export function RoomGate({ code, reason }: { code: string; reason: 'not_member' | 'not_found' | 'invalid' }) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="border-b bg-card">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center px-4 sm:px-6">
          <BrandLogo />
        </div>
      </header>
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center gap-6 px-4 py-10">
        {reason === 'not_member' ? (
          <>
            <div className="text-center">
              <ShieldAlert className="mx-auto size-8 text-primary" aria-hidden="true" />
              <h1 className="mt-3 text-2xl font-semibold tracking-tight">Join room {code}</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                You need to join this room before you can see its cart. Pick a display name to continue.
              </p>
            </div>
            <EntryCard initialCode={code} />
          </>
        ) : (
          <div className="rounded-2xl border bg-card p-6 text-center shadow-sm">
            <SearchX className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
            <h1 className="mt-3 text-xl font-semibold">
              {reason === 'invalid' ? 'That room code is not valid' : 'Room not found'}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground text-pretty">
              {reason === 'invalid'
                ? 'Room codes are 6 characters using letters and numbers.'
                : `We couldn't find room ${code}. It may have expired, or the code may be mistyped.`}
            </p>
            <Button className="mt-5" render={<Link href="/" />}>
              Back to home
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
