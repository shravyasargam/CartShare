'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Printer } from 'lucide-react'
import { toast } from 'sonner'
import { DemoBanner } from '@/components/demo-banner'
import { ActivityFeed } from '@/components/room/activity-feed'
import { AvatarStack } from '@/components/room/avatar'
import { CartList } from '@/components/room/cart-list'
import { ConfirmDialog } from '@/components/room/confirm-dialog'
import { CopyCodeButton } from '@/components/room/copy-code-button'
import { DeliveryProgress } from '@/components/room/delivery-progress'
import { ItemDialog } from '@/components/room/item-dialog'
import { ParticipantsPanel } from '@/components/room/participants-panel'
import { RoomShell } from '@/components/room/room-shell'
import { RoomGate, RoomLoading } from '@/components/room/room-states'
import { SummaryCards } from '@/components/room/summary-cards'
import { SyncIndicator } from '@/components/room/sync-indicator'
import { Button } from '@/components/ui/button'
import { useRoom } from '@/hooks/use-room'
import { computeCartTotals, computeContributions, computeDeliveryStatus } from '@/lib/cart-math'
import type { CartItem } from '@/lib/types'

export function RoomApp({ code }: { code: string }) {
  const router = useRouter()
  const room = useRoom(code)
  const { data } = room

  const [dialog, setDialog] = useState<{ open: boolean; itemId?: string }>({ open: false })
  const [removing, setRemoving] = useState<CartItem | null>(null)
  const [leaving, setLeaving] = useState(false)

  const derived = useMemo(() => {
    if (!data) return null
    const totals = computeCartTotals(data.items)
    return {
      totals,
      delivery: computeDeliveryStatus(totals.totalPaise),
      contributions: computeContributions(data.items, data.participants),
      now: new Date(data.serverTime).getTime(),
    }
  }, [data])

  if (room.fatalError) {
    const reason = room.fatalError.status === 403 ? 'not_member' : room.fatalError.status === 400 ? 'invalid' : 'not_found'
    return <RoomGate code={code} reason={reason} />
  }

  const editingItem = dialog.itemId ? data?.items.find((i) => i.id === dialog.itemId) : undefined
  const activeNames = data?.participants.filter((p) => p.active).map((p) => p.name) ?? []

  const header = (
    <header className="no-print sticky top-0 z-20 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex min-h-16 w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <div className="min-w-0">
          <h1 className="truncate text-lg font-semibold tracking-tight">{data?.room.name ?? 'Loading room…'}</h1>
          <p className="text-xs text-muted-foreground">
            Room code <span className="font-mono font-semibold tracking-widest text-foreground">{code}</span>
            {data && <> · signed in as {data.me.name}</>}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {activeNames.length > 0 && (
            <div className="hidden lg:block">
              <AvatarStack names={activeNames} />
            </div>
          )}
          <SyncIndicator status={room.status} onRefresh={() => room.refresh()} refreshing={room.isValidating} />
          <div className="hidden sm:block">
            <CopyCodeButton code={code} />
          </div>
          <div className="sm:hidden">
            <CopyCodeButton code={code} compact />
          </div>
          <Button variant="outline" size="icon" render={<Link href={`/room/${code}/receipt`} />} aria-label="Open printable receipt">
            <Printer aria-hidden="true" />
          </Button>
        </div>
      </div>
    </header>
  )

  return (
    <RoomShell code={code} header={header} onLeave={() => setLeaving(true)}>
      {!data || !derived ? (
        <RoomLoading />
      ) : (
        <div className="flex flex-col gap-4">
          {data.mode === 'demo' && <DemoBanner />}
          <SummaryCards totals={derived.totals} delivery={derived.delivery} />
          <DeliveryProgress delivery={derived.delivery} totalPaise={derived.totals.totalPaise} />
          <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]">
            <CartList
              items={data.items}
              onAdd={() => setDialog({ open: true })}
              onEdit={(item) => setDialog({ open: true, itemId: item.id })}
              onRemove={(item) => setRemoving(item)}
              onChangeQuantity={(item, delta) => room.changeQuantity(item.id, delta)}
            />
            <div className="flex flex-col gap-4">
              <ParticipantsPanel participants={data.participants} contributions={derived.contributions} meId={data.me.id} />
              <ActivityFeed activities={data.activities} now={derived.now} />
            </div>
          </div>
        </div>
      )}

      <ItemDialog
        open={dialog.open}
        onOpenChange={(open) => setDialog((d) => ({ ...d, open }))}
        item={editingItem}
        onSubmit={(input) =>
          editingItem ? room.updateItem(editingItem.id, { ...input, version: editingItem.version }) : room.addItem(input)
        }
      />

      <ConfirmDialog
        open={removing !== null}
        onOpenChange={(open) => !open && setRemoving(null)}
        title={`Remove ${removing?.name ?? 'product'}?`}
        description="This removes the product from the shared cart for everyone. The removal will be recorded in the activity feed."
        confirmLabel="Remove product"
        onConfirm={async () => {
          if (removing) await room.removeItem(removing.id, removing.name)
        }}
      />

      <ConfirmDialog
        open={leaving}
        onOpenChange={setLeaving}
        title="Leave this room?"
        description="Products you added will stay in the cart so the group receipt stays accurate. You can rejoin later with the room code."
        confirmLabel="Leave room"
        onConfirm={async () => {
          try {
            await room.leaveRoom()
            toast.success('You left the room')
            router.push('/')
          } catch {
            toast.error('Could not leave the room. Please try again.')
          }
        }}
      />
    </RoomShell>
  )
}
