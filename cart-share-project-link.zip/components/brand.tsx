import Link from 'next/link'
import { ShoppingBasket } from 'lucide-react'
import { cn } from '@/lib/utils'
import { APP_CONFIG } from '@/lib/config'

export function BrandMark({ className }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        'inline-flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm',
        className,
      )}
    >
      <ShoppingBasket className="size-5" />
    </span>
  )
}

export function BrandLogo({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <Link
      href="/"
      className={cn('inline-flex items-center gap-2.5 rounded-lg focus-visible:ring-3 focus-visible:ring-ring/50 outline-none', className)}
    >
      <BrandMark />
      {!compact && (
        <span className="text-lg font-semibold tracking-tight text-foreground">{APP_CONFIG.name}</span>
      )}
      <span className="sr-only">{compact ? `${APP_CONFIG.name} home` : ' home'}</span>
    </Link>
  )
}
