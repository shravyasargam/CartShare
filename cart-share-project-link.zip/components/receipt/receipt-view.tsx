'use client'

import { useMemo } from 'react'
import Link from 'next/link'
import { ArrowLeft, Printer } from 'lucide-react'
import { BrandMark } from '@/components/brand'
import { RoomGate, RoomLoading } from '@/components/room/room-states'
import { Button } from '@/components/ui/button'
import { useRoom } from '@/hooks/use-room'
import { computeCartTotals, computeContributions, computeDeliveryStatus } from '@/lib/cart-math'
import { APP_CONFIG } from '@/lib/config'
import { formatINR, lineSubtotalPaise } from '@/lib/money'
import { formatExact } from '@/lib/time'

export function ReceiptView({ code }: { code: string }) {
  const { data, fatalError } = useRoom(code)

  const derived = useMemo(() => {
    if (!data) return null
    const totals = computeCartTotals(data.items)
    return {
      totals,
      delivery: computeDeliveryStatus(totals.totalPaise),
      contributions: computeContributions(data.items, data.participants).filter((c) => c.active || c.products > 0),
    }
  }, [data])

  if (fatalError) {
    const reason = fatalError.status === 403 ? 'not_member' : fatalError.status === 400 ? 'invalid' : 'not_found'
    return <RoomGate code={code} reason={reason} />
  }
  if (!data || !derived) return <RoomLoading />

  const generatedAt = formatExact(data.serverTime)

  return (
    <div className="min-h-dvh bg-muted/40 py-6 print:bg-white print:py-0">
      <div className="no-print mx-auto mb-4 flex w-full max-w-3xl items-center justify-between gap-3 px-4">
        <Button variant="ghost" render={<Link href={`/room/${code}`} />}>
          <ArrowLeft aria-hidden="true" />
          Back to room
        </Button>
        <Button onClick={() => window.print()} disabled={data.items.length === 0}>
          <Printer aria-hidden="true" />
          Print receipt
        </Button>
      </div>

      <main className="print-area mx-auto w-full max-w-3xl rounded-2xl border bg-card p-6 shadow-sm sm:p-10">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b pb-6">
          <div className="flex items-center gap-3">
            <BrandMark className="print:hidden" />
            <div>
              <p className="text-xl font-semibold tracking-tight">{APP_CONFIG.name}</p>
              <p className="text-xs text-muted-foreground">{APP_CONFIG.tagline}</p>
            </div>
          </div>
          <dl className="grid grid-cols-[auto_auto] gap-x-4 gap-y-1 text-sm">
            <dt className="text-muted-foreground">Room</dt>
            <dd className="font-medium">{data.room.name}</dd>
            <dt className="text-muted-foreground">Code</dt>
            <dd className="font-mono font-semibold tracking-widest">{data.room.code}</dd>
            <dt className="text-muted-foreground">Generated</dt>
            <dd>{generatedAt}</dd>
          </dl>
        </header>

        <h1 className="mt-6 text-lg font-semibold">Group shopping receipt</h1>

        {data.items.length === 0 ? (
          <p className="mt-4 rounded-lg bg-muted p-6 text-center text-sm text-muted-foreground">
            The cart is empty. Add products in the room to generate a receipt.
          </p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <caption className="sr-only">Products in the shared cart</caption>
              <thead>
                <tr className="border-b text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th scope="col" className="py-2 pr-3 font-medium">Product</th>
                  <th scope="col" className="py-2 pr-3 font-medium">Added by</th>
                  <th scope="col" className="py-2 pr-3 text-right font-medium">Qty</th>
                  <th scope="col" className="py-2 pr-3 text-right font-medium">Unit price</th>
                  <th scope="col" className="py-2 text-right font-medium">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((item) => (
                  <tr key={item.id} className="print-row border-b last:border-0">
                    <td className="py-2.5 pr-3">
                      <span className="font-medium">{item.name}</span>
                      {item.category && <span className="block text-xs text-muted-foreground">{item.category}</span>}
                    </td>
                    <td className="py-2.5 pr-3">{item.addedByName}</td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">{item.quantity}</td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">{formatINR(item.unitPricePaise)}</td>
                    <td className="py-2.5 text-right font-medium tabular-nums">{formatINR(lineSubtotalPaise(item))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <section aria-labelledby="totals-heading" className="print-row mt-6 grid gap-6 border-t pt-6 sm:grid-cols-2">
          <div>
            <h2 id="totals-heading" className="text-sm font-semibold">
              Summary
            </h2>
            <dl className="mt-3 flex flex-col gap-1.5 text-sm">
              <Row label="Unique products" value={derived.totals.uniqueProducts.toLocaleString('en-IN')} />
              <Row label="Total quantity" value={derived.totals.totalUnits.toLocaleString('en-IN')} />
              <Row
                label="Free delivery"
                value={
                  derived.delivery.reached
                    ? `Unlocked (over ${formatINR(derived.delivery.thresholdPaise)})`
                    : `${formatINR(derived.delivery.remainingPaise)} short`
                }
              />
              <div className="mt-2 flex items-baseline justify-between border-t pt-3">
                <dt className="font-semibold">Grand total</dt>
                <dd className="text-xl font-semibold tabular-nums">{formatINR(derived.totals.totalPaise)}</dd>
              </div>
            </dl>
          </div>
          <div>
            <h2 className="text-sm font-semibold">Contribution by participant</h2>
            <dl className="mt-3 flex flex-col gap-1.5 text-sm">
              {derived.contributions.map((c) => (
                <Row
                  key={c.participantId}
                  label={`${c.name}${c.active ? '' : ' (left)'} · ${c.products} items`}
                  value={`${formatINR(c.totalPaise)} (${c.sharePercent.toFixed(0)}%)`}
                />
              ))}
            </dl>
          </div>
        </section>

        <footer className="mt-8 border-t pt-4 text-center text-xs text-muted-foreground">
          Prices in Indian Rupees (INR). This is a shared shopping summary, not a tax invoice.
        </footer>
      </main>
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium tabular-nums">{value}</dd>
    </div>
  )
}
