import { Activity, Printer, ShoppingCart, Truck, Users } from 'lucide-react'
import { APP_CONFIG } from '@/lib/config'
import { formatINR } from '@/lib/money'

const STEPS = [
  {
    icon: Users,
    title: 'Open a room',
    body: 'Create a shopping room and share its 6-character code with roommates, classmates, or teammates.',
  },
  {
    icon: ShoppingCart,
    title: 'Build one cart',
    body: 'Everyone adds products with quantity and price. Duplicates are easy to spot, and totals update for all.',
  },
  {
    icon: Activity,
    title: 'See who did what',
    body: 'Every addition, edit, and removal is recorded with a name and time, so nothing gets lost in chat.',
  },
  {
    icon: Truck,
    title: 'Hit free delivery',
    body: `Track progress towards the ${formatINR(APP_CONFIG.freeDeliveryThresholdPaise)} free-delivery threshold together.`,
  },
  {
    icon: Printer,
    title: 'Print the receipt',
    body: 'Generate a clean group receipt with each person’s contribution, ready to print or save as PDF.',
  },
]

export function HowItWorks() {
  return (
    <section aria-labelledby="how-heading" className="mx-auto w-full max-w-6xl px-4 py-14 sm:px-6">
      <h2 id="how-heading" className="text-2xl font-semibold tracking-tight text-balance">
        How shared shopping works
      </h2>
      <p className="mt-2 max-w-2xl text-muted-foreground text-pretty">
        No more scattered notes and long message threads. One room keeps the list, the people, and the money in sync.
      </p>
      <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {STEPS.map((step, index) => (
          <li key={step.title} className="rounded-2xl border bg-card p-5 transition-shadow hover:shadow-sm">
            <div className="flex items-center gap-3">
              <span className="inline-flex size-9 items-center justify-center rounded-lg bg-secondary text-secondary-foreground">
                <step.icon className="size-4" aria-hidden="true" />
              </span>
              <span className="font-mono text-xs text-muted-foreground">Step {index + 1}</span>
            </div>
            <h3 className="mt-4 font-semibold">{step.title}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}
