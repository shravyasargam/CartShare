'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight, Loader2, LogIn, Plus } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ApiError, apiRequest } from '@/lib/client-api'
import { displayNameSchema, roomCodeSchema, roomNameSchema } from '@/lib/validation'
import { cn } from '@/lib/utils'

type Mode = 'create' | 'join'

function firstError(result: { success: boolean; error?: { issues: { message: string }[] } }) {
  return result.success ? undefined : result.error?.issues[0]?.message
}

export function EntryCard({ initialCode = '' }: { initialCode?: string }) {
  const router = useRouter()
  const [mode, setMode] = useState<Mode>(initialCode ? 'join' : 'create')
  const [displayName, setDisplayName] = useState('')
  const [roomName, setRoomName] = useState('')
  const [code, setCode] = useState(initialCode)
  const [includeSamples, setIncludeSamples] = useState(true)
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const [submitting, setSubmitting] = useState(false)
  const [serverError, setServerError] = useState<string | null>(null)

  const nameError = firstError(displayNameSchema.safeParse(displayName))
  const roomNameError = firstError(roomNameSchema.safeParse(roomName))
  const codeError = firstError(roomCodeSchema.safeParse(code))
  const hasErrors = Boolean(nameError || (mode === 'create' ? roomNameError : codeError))

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setTouched({ displayName: true, roomName: true, code: true })
    setServerError(null)
    if (hasErrors) return
    setSubmitting(true)
    try {
      if (mode === 'create') {
        const res = await apiRequest<{ code: string }>('/api/rooms', {
          method: 'POST',
          body: { displayName, roomName, includeSamples },
        })
        toast.success(`Room created. Share code ${res.code} with your group.`)
        router.push(`/room/${res.code}`)
      } else {
        const res = await apiRequest<{ code: string; alreadyMember: boolean }>('/api/rooms/join', {
          method: 'POST',
          body: { displayName, code },
        })
        toast.success(res.alreadyMember ? 'Welcome back! You are already in this room.' : 'You joined the room.')
        router.push(`/room/${res.code}`)
      }
    } catch (err) {
      setServerError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.')
      setSubmitting(false)
    }
  }

  const show = (field: string, error?: string) => (touched[field] ? error : undefined)

  return (
    <div className="rounded-2xl border bg-card p-5 shadow-sm sm:p-6">
      <div role="tablist" aria-label="Choose how to start" className="grid grid-cols-2 gap-1 rounded-xl bg-muted p-1">
        {(
          [
            { id: 'create', label: 'Create a room', icon: Plus },
            { id: 'join', label: 'Join a room', icon: LogIn },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            id={`tab-${tab.id}`}
            aria-selected={mode === tab.id}
            aria-controls="entry-panel"
            onClick={() => {
              setMode(tab.id)
              setServerError(null)
            }}
            className={cn(
              'inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors outline-none focus-visible:ring-3 focus-visible:ring-ring/50',
              mode === tab.id ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            <tab.icon className="size-4" aria-hidden="true" />
            {tab.label}
          </button>
        ))}
      </div>

      <form
        id="entry-panel"
        role="tabpanel"
        aria-labelledby={`tab-${mode}`}
        onSubmit={handleSubmit}
        noValidate
        className="mt-5 flex flex-col gap-4"
      >
        <Field
          id="displayName"
          label="Your display name"
          hint="Shown to others in the room. No email or password needed."
          error={show('displayName', nameError)}
        >
          <Input
            id="displayName"
            autoComplete="nickname"
            placeholder="e.g. Priya"
            value={displayName}
            maxLength={32}
            onChange={(e) => setDisplayName(e.target.value)}
            onBlur={() => setTouched((t) => ({ ...t, displayName: true }))}
            aria-invalid={Boolean(show('displayName', nameError))}
            aria-describedby="displayName-hint displayName-error"
            className="h-10"
          />
        </Field>

        {mode === 'create' ? (
          <>
            <Field id="roomName" label="Room name" error={show('roomName', roomNameError)}>
              <Input
                id="roomName"
                placeholder="e.g. Flat 4B monthly groceries"
                value={roomName}
                maxLength={48}
                onChange={(e) => setRoomName(e.target.value)}
                onBlur={() => setTouched((t) => ({ ...t, roomName: true }))}
                aria-invalid={Boolean(show('roomName', roomNameError))}
                aria-describedby="roomName-error"
                className="h-10"
              />
            </Field>
            <label className="flex cursor-pointer items-start gap-3 rounded-lg border bg-muted/40 p-3 text-sm">
              <input
                type="checkbox"
                checked={includeSamples}
                onChange={(e) => setIncludeSamples(e.target.checked)}
                className="mt-0.5 size-4 accent-primary"
              />
              <span>
                <span className="font-medium">Start with sample groceries</span>
                <span className="block text-muted-foreground">
                  Adds rice, milk, bread, vegetables and more so you can explore right away.
                </span>
              </span>
            </label>
          </>
        ) : (
          <Field id="code" label="Room code" hint="Ask the room owner for the 6-character code." error={show('code', codeError)}>
            <Input
              id="code"
              placeholder="K7PX2Q"
              value={code}
              maxLength={7}
              autoCapitalize="characters"
              spellCheck={false}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              onBlur={() => setTouched((t) => ({ ...t, code: true }))}
              aria-invalid={Boolean(show('code', codeError))}
              aria-describedby="code-hint code-error"
              className="h-10 font-mono text-base tracking-[0.3em] uppercase"
            />
          </Field>
        )}

        {serverError && (
          <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive">
            {serverError}
          </p>
        )}

        <Button type="submit" size="lg" className="h-11 text-sm" disabled={submitting || (touched.displayName && hasErrors)}>
          {submitting ? (
            <Loader2 className="animate-spin" aria-hidden="true" />
          ) : mode === 'create' ? (
            <Plus aria-hidden="true" />
          ) : (
            <LogIn aria-hidden="true" />
          )}
          {mode === 'create' ? 'Create a Shopping Room' : 'Join Existing Room'}
          {!submitting && <ArrowRight className="ml-auto sm:ml-0" aria-hidden="true" />}
        </Button>
      </form>
    </div>
  )
}

function Field({
  id,
  label,
  hint,
  error,
  children,
}: {
  id: string
  label: string
  hint?: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {error ? (
        <p id={`${id}-error`} className="text-xs text-destructive">
          {error}
        </p>
      ) : (
        hint && (
          <p id={`${id}-hint`} className="text-xs text-muted-foreground">
            {hint}
          </p>
        )
      )}
    </div>
  )
}
