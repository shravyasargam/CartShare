'use client'

import useSWR from 'swr'
import { toast } from 'sonner'
import { APP_CONFIG } from '@/lib/config'
import { ApiError, apiRequest, fetcher } from '@/lib/client-api'
import type { RoomState } from '@/lib/types'
import type { ItemInput } from '@/lib/validation'

export type SyncStatus = 'connecting' | 'connected' | 'disconnected'

const FATAL_STATUSES = new Set([400, 403, 404])

export function roomKey(code: string) {
  return `/api/rooms/${encodeURIComponent(code)}`
}

export function useRoom(code: string) {
  const key = roomKey(code)
  const { data, error, isLoading, isValidating, mutate } = useSWR<RoomState, ApiError>(key, fetcher, {
    // Keep polling while we have a room; stop on authorization / not-found errors.
    refreshInterval: (latest) => (latest ? APP_CONFIG.syncIntervalMs : 0),
    refreshWhenHidden: false,
    revalidateOnFocus: true,
    revalidateOnReconnect: true,
    keepPreviousData: true,
    onErrorRetry: (err, _key, _config, revalidate, { retryCount }) => {
      if (FATAL_STATUSES.has(err.status)) return
      setTimeout(() => revalidate({ retryCount }), Math.min(15_000, 1_000 * 2 ** retryCount))
    },
  })

  const fatalError = error && FATAL_STATUSES.has(error.status) ? error : undefined
  const status: SyncStatus = error && !fatalError ? 'disconnected' : !data ? 'connecting' : 'connected'

  async function run(request: () => Promise<RoomState>, success?: string) {
    try {
      const next = await request()
      await mutate(next, { revalidate: false })
      if (success) toast.success(success)
      return true
    } catch (err) {
      const apiError = err instanceof ApiError ? err : new ApiError(0, 'Something went wrong.')
      if (apiError.latestState) await mutate(apiError.latestState, { revalidate: false })
      else if (apiError.status === 404 || apiError.status === 409) await mutate()
      toast.error(apiError.message)
      return false
    }
  }

  const itemsUrl = `${key}/items`

  return {
    data,
    fatalError,
    isLoading,
    isValidating,
    status,
    refresh: () => mutate(),
    addItem: (input: ItemInput) =>
      run(() => apiRequest<RoomState>(itemsUrl, { method: 'POST', body: input }), `Added ${input.name}`),
    updateItem: (id: string, input: ItemInput & { version: number }) =>
      run(() => apiRequest<RoomState>(`${itemsUrl}/${id}`, { method: 'PUT', body: input }), 'Product updated'),
    changeQuantity: (id: string, delta: number) =>
      run(() => apiRequest<RoomState>(`${itemsUrl}/${id}`, { method: 'PATCH', body: { delta } })),
    removeItem: (id: string, name: string) =>
      run(() => apiRequest<RoomState>(`${itemsUrl}/${id}`, { method: 'DELETE' }), `Removed ${name}`),
    leaveRoom: async () => {
      await apiRequest(`${key}/leave`, { method: 'POST' })
      await mutate(undefined, { revalidate: false })
    },
  }
}

export type RoomController = ReturnType<typeof useRoom>
